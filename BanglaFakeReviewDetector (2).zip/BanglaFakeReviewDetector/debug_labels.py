"""Debug script to analyze model output interpretation."""
import os, re, numpy as np, joblib, torch, torch.nn as nn, torch.nn.functional as F

EMOJI_PATTERN = re.compile(
    "[" "\U0001F300-\U0001FAFF" "\U00002600-\U000027BF"
    "\U0001F1E6-\U0001F1FF" "\U00002190-\U000021FF" "]+", flags=re.UNICODE)

def clean_text(text):
    text = re.sub(r"http\S+|www\.\S+", " ", text)
    text = EMOJI_PATTERN.sub(" ", text)
    text = re.sub(r"([\u0964!?.\-_=~*])\1{1,}", r"\1", text)
    text = re.sub(r"(#\w+)(\s*\1){1,}", r"\1", text)
    return re.sub(r"\s+", " ", text).strip()

def basic_tokenize(text):
    return re.findall(r"[\u0980-\u09FFa-zA-Z0-9]+", text)

def encode(tokens, vocab, max_len):
    unk = vocab["<unk>"]
    ids = [vocab.get(t, unk) for t in tokens[:max_len]]
    return ids + [vocab["<pad>"]] * (max_len - len(ids))

class RNNClassifier(nn.Module):
    def __init__(self, embedding_matrix, hidden_dim=64):
        super().__init__()
        self.embedding = nn.Embedding.from_pretrained(
            torch.tensor(embedding_matrix, dtype=torch.float32), padding_idx=0)
        embed_dim = embedding_matrix.shape[1]
        self.rnn = nn.RNN(embed_dim, hidden_dim, batch_first=True, nonlinearity="tanh")
        self.fc = nn.Linear(hidden_dim, 1)
    def forward(self, x):
        embedded = self.embedding(x)
        rnn_out, _ = self.rnn(embedded)
        mask = (x != 0).unsqueeze(-1).float()
        pooled = torch.sum(rnn_out * mask, dim=1) / torch.clamp(mask.sum(dim=1), min=1e-8)
        return self.fc(pooled).squeeze(-1)

class LSTMAttentionClassifier(nn.Module):
    def __init__(self, embedding_matrix, hidden_dim=64):
        super().__init__()
        self.embedding = nn.Embedding.from_pretrained(
            torch.tensor(embedding_matrix, dtype=torch.float32), padding_idx=0)
        embed_dim = embedding_matrix.shape[1]
        self.lstm = nn.LSTM(embed_dim, hidden_dim, batch_first=True)
        self.attention = nn.Linear(hidden_dim, 1)
        self.fc = nn.Linear(hidden_dim, 1)
    def forward(self, x):
        embedded = self.embedding(x)
        lstm_out, _ = self.lstm(embedded)
        attn_scores = self.attention(lstm_out).squeeze(-1)
        attn_scores = attn_scores.masked_fill(~(x != 0), float("-inf"))
        attn_weights = F.softmax(attn_scores, dim=1)
        context = torch.sum(lstm_out * attn_weights.unsqueeze(-1), dim=1)
        return self.fc(context).squeeze(-1)

def run_analysis(model_name, model_cls, weights_file, model_dir):
    print(f"\n{'='*70}")
    print(f"  MODEL: {model_name}")
    print(f"{'='*70}")
    
    vocab = joblib.load(os.path.join(model_dir, "vocab.joblib"))
    config = joblib.load(os.path.join(model_dir, "config.joblib"))
    label_map = joblib.load(os.path.join(model_dir, "label_map.joblib"))
    
    print(f"  label_map: {label_map}")
    print(f"  config: {config}")
    print(f"  vocab size: {len(vocab)}")
    
    dummy = np.zeros((len(vocab), config["embed_dim"]), dtype=np.float32)
    model = model_cls(dummy, hidden_dim=config["hidden_dim"])
    sd = torch.load(os.path.join(model_dir, weights_file), map_location="cpu", weights_only=True)
    model.load_state_dict(sd)
    model.eval()
    
    # FC layer bias tells us the default prediction direction
    fc_bias = model.fc.bias.item()
    print(f"  fc layer bias: {fc_bias:.4f}")
    print(f"  sigmoid(bias) = {torch.sigmoid(torch.tensor(fc_bias)).item():.4f}")
    print()
    
    tests = [
        ("Generic positive (likely fake)",  "পণ্যটি অনেক ভালো দারুন প্রোডাক্ট"),
        ("Specific positive (likely real)", "চিকেন এর সাথে সাথে সার্ভিসও অনেক ভালো ছিল আমি রেগুলার এখানে যাই"),
        ("Specific negative (likely real)", "খাবারের মান খুবই খারাপ ছিল ডেলিভারি অনেক দেরিতে এসেছে"),
        ("Exaggerated praise (likely fake)", "সেরা সেরা সেরা অসাধারণ দারুণ বেস্ট প্রোডাক্ট"),
        ("Short negative",                  "খুব বাজে সার্ভিস টাকা নষ্ট"),
    ]
    
    print(f"  {'Description':<40} {'Logit':>8} {'Sigmoid':>8}  Interp_A(sig=Pfake)  Interp_B(sig=Pauth)")
    print(f"  {'-'*40} {'-'*8} {'-'*8}  {'-'*19}  {'-'*19}")
    
    for desc, text in tests:
        tokens = basic_tokenize(clean_text(text))
        ids = encode(tokens, vocab, config["max_seq_len"])
        x = torch.tensor([ids], dtype=torch.long)
        with torch.no_grad():
            logit = model(x).item()
            sig = torch.sigmoid(torch.tensor(logit)).item()
        
        # Interpretation A: sigmoid = P(fake)  [original code convention]
        if sig > 0.5:
            vA, cA = "FAKE", sig
        else:
            vA, cA = "AUTH", 1 - sig
        
        # Interpretation B: sigmoid = P(authentic)  [my changed code]
        if sig >= 0.5:
            vB, cB = "AUTH", sig
        else:
            vB, cB = "FAKE", 1 - sig
        
        print(f"  {desc:<40} {logit:>8.4f} {sig:>8.4f}  {vA} ({cA:.1%})        {vB} ({cB:.1%})")

if __name__ == "__main__":
    base = os.path.dirname(os.path.abspath(__file__))
    run_analysis("LSTM+Attention", LSTMAttentionClassifier, "lstm_model.pt",
                 os.path.join(base, "saved_lstm_model"))
    run_analysis("RNN", RNNClassifier, "rnn_model.pt",
                 os.path.join(base, "saved_rnn_model"))
